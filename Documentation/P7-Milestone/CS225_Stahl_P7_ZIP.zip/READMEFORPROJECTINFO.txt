RUN THE MAIN FUNCTION IN MANAGERCLASS

DO NOT EDIT OR REMOVE FILES.

DOCUMENTS FOR THE PROJECT SPRINT ASSIGNMENT CAN BE FOUND IN THE ACCORDING MILESTONE DOCUMENT FOLDER IN
..\Documentation\P<X>-Milestone

Dragging is finicky due to just how mouse events work in java, I never bothered to add the offset since the core functionality is there and I'm not getting graded on perfection.